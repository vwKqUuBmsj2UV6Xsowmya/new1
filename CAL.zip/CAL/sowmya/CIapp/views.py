from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from datetime import date, datetime
from .models import *
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required

# Create your views here.

# CI function name for index.html page


def CI(request):
    return render(request, 'index.html')

# add fuction for result.html page


def add(request):
    if request.method == 'POST':
        dat = request.POST.get('dat')
        value4 = request.POST.get('value4')
        value5 = request.POST.get('value5')
        value1 = int(request.POST.get('value1'))
        value2 = int(request.POST.get('value2'))
        value3 = float(request.POST.get('value3'))
        # The above 6 lines for form lo enter chesina data tho click events cheyali
        result = value1 * value3/100
        # result will display intrest amount per month
        intrest = value2 * result
        # intrest will diplay value2 ante months * intrest
        amount = intrest + value1
        months = value2//12
        remainder = value2 % 12
        dat_obj = datetime.strptime(dat, '%Y-%m-%d')
        year_extract = dat_obj.year
        munt_extract = dat_obj.month
        day_extract = dat_obj.day
        # today = date.today()
        year = dat_obj.year + months
        mnth = dat_obj.month + remainder
        day = dat_obj.day
        context_values = {'dat': dat, 'mnth': mnth, 'day': day, 'year': year, 'result': result, 'value1': value1, 'amount': amount,
                          'value2': value2, 'value4': value4, 'value5': value5, 'value3': value3, 'months': months, 'remainder': remainder}
        request.session['context_values'] = context_values


# form lo enter chesina data database
        data = request.POST
        Amount = data.get('value1')
        Intrest = data.get('value3')
        Lender = data.get('value4')
        Amount_given_to = data.get('value5')
        intrest_per_month = 0
        final_amount = 0
        For_no_of_years = 0
        For_no_of_mnths = 0
        future_year = 0
        future_month = 0
        future_day = 0
        total_final_amount = 0
        For_no_of_months = data.get('value2')
        Borrowed_date = data.get('dat')
        si.objects.create(
            Amount=Amount,
            Intrest=Intrest,
            Lender=Lender,
            Amount_given_to=Amount_given_to,
            intrest_per_month=intrest_per_month,
            For_no_of_months=For_no_of_months,
            final_amount=final_amount,
            Borrowed_date=Borrowed_date,
            For_no_of_years=For_no_of_years,
            For_no_of_mnths=For_no_of_mnths,
            future_year=future_year,
            future_month=future_month,
            future_day=future_day,
            total_final_amount=total_final_amount,
        )
        return render(request, 'result2.html', context_values)
    else:
        return render(request, 'index.html')


# value1 = Principal
# value2 = Months (T)
# valu3 = Rate Intrest
# value4 = amount given by
#  value5 = amount given to
def table(request):
    queryset = si.objects.all()
    if request.GET.get('search'):
        queryset = queryset.filter(Lender__icontains=request.GET.get('search'))
    # paginator
    paginator = Paginator(queryset, 5)

    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context = {'new': page_obj}

    return render(request, 'table.html', context)


def delete_si(request, id):

    queryset = si.objects.get(id=id)
    queryset.delete()
    return redirect('/tbl/')


def view_si(request, id):

    queryset = get_object_or_404(si, id=id)

    context = {'new1': queryset}
    return render(request, 'result.html', context)


def login_page(request):
    if request.method == 'POST':

        username = request.POST.get('username')
        password = request.POST.get('password')

        if not User.objects.filter(username=username).exists():
            messages.info(request, 'Invalid Username')
            return redirect('/login/')
        user = authenticate(username=username, password=password)
        if user is None:
            messages.info(request, 'Invalid password')
            return redirect('/login/')
        else:
            login(request, user)
            return redirect('/')
    return render(request, 'login.html')


def register_page(request):
    # form lo fill chesina data database loki velladam
    if request.method == 'POST':
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        username = request.POST.get('username')
        password = request.POST.get('password')

        # if username already vunte
        user = User.objects.filter(username=username)
        if user.exists():
            messages.info(request, 'username already taken')
            return redirect('/register/')

        user = User.objects.create(first_name=first_name,
                                   last_name=last_name,
                                   username=username
                                   )
        user.set_password(password)
        user.save()
        messages.info(request, 'Account created Successfully')
        return redirect('/register/')
    return render(request, 'register.html')


def logout_page(request):
    logout(request)
    return redirect('/login/')
