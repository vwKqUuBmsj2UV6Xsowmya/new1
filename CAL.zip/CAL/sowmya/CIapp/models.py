from django.db import models
from django.contrib.auth.models import User


# Create your models here.
class si(models.Model):
    # Login
    user = models.ForeignKey(User,on_delete=models.SET_NULL,null = True,blank=True)
    # end login
    Lender = models.CharField(max_length=100)
    Borrowed_date = models.CharField(max_length=100,blank=True, null=True)
    Amount_given_to = models.CharField(max_length=100)
    Amount = models.IntegerField()
    Intrest = models.FloatField()
    intrest_per_month = models.FloatField(blank=True, null=True)
    For_no_of_months = models.IntegerField(blank=True, null=True)
    final_amount =models.FloatField(blank=True, null=True)
    For_no_of_years = models.IntegerField(blank=True, null=True)
    For_no_of_mnths = models.IntegerField(blank=True, null=True)
    future_year = models.IntegerField(blank=True, null=True)
    future_month = models.IntegerField(blank=True, null=True)
    future_day = models.IntegerField(blank=True, null=True)
    total_final_amount= models.IntegerField(blank=True, null=True)
# above vunnavi anni table column names in db. Below oka def function yendhuku ante {{context}} values ni DB lo enter cheyatam kosam
    def save(self, *args, **kwargs):
        if self.Borrowed_date:
            # Split the Borrowed_date string into year, month, and day components
            borrowed_year, borrowed_month, borrowed_day = map(int, self.Borrowed_date.split('-'))
            
            # Convert self.For_no_of_months to an integer
            for_no_of_months = int(self.For_no_of_months)
            
            # Calculate future month by adding For_no_of_months
            future_month = borrowed_month + for_no_of_months
            
            # Calculate future year by adding overflow months
            future_year = borrowed_year + (future_month - 1) // 12
            
            # Adjust future month if it overflows 12
            future_month = (future_month - 1) % 12 + 1
            
            # Update future_year and future_month attributes
            self.future_year = future_year
            self.future_month = future_month
            self.future_day = borrowed_day


        
            

        # Calculate ptr_div_100 and store the result in the database
        amount = float(self.Amount)
        interest = float(self.Intrest)
        final_months = int(self.For_no_of_months)
        self.intrest_per_month = amount * interest / 100
        self.final_amount = self.intrest_per_month * final_months
        self.total_final_amount = self.final_amount + amount
        self.For_no_of_years = final_months//12
        self.For_no_of_mnths = final_months%12
        super().save(*args, **kwargs)